﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ToyotaRSS.Models;
using ToyotaRSS.Controller;
using ToyotaRSS.Security;

namespace ToyotaRSS.Views
{
    public partial class JobEditor : Form
    {
        private Job m_job;
        public JobEditor()
        {
            Init();
            m_job = new Job();
            m_jobId.Text = "";
            m_cbStatus.Enabled = false;
            m_btnSave.Text = "Create";
        }

        public JobEditor(Job currentJob)
        {
            Init();
            m_job = currentJob;
        }

        private void Init()
        {
            InitializeComponent();
            this.AcceptButton = m_btnSave;
            this.CancelButton = m_btnCancel;
            this.CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;

            Employee worker = LogonManager.instance.CurrentEmployee;
            if (worker != null && worker.role == EmployeeRole.Worker)
            {
                m_cbPriority.Enabled = false;
                m_cbOutlet.Enabled = false;
                m_cbCar.Enabled = false;
                m_cbWorker.Enabled = false;
            }

            Customer cust = LogonManager.instance.CurrentCustomer;
            if (cust != null)
            {
                m_cbWorker.Enabled = false;
                m_cbStatus.Enabled = false;
            }
        }

        public Job CurrentJob{
            get => m_job;
            set { m_job = value; }
        }

        private void JobEditor_Load(object sender, EventArgs evt)
        {
            foreach (Outlet o in ToyotaService.Instance.GetOutlets())
            {
                ItemData item = new ItemData(o.name, o);
                m_cbOutlet.Items.Add(item);
                if (m_job.outlet != null && o.id == m_job.outlet.id)
                    m_cbOutlet.SelectedItem = item;
            }

            IList<Car> myCars = ToyotaService.Instance.GetMyCars();
            foreach (Car c in myCars)
            {
                ItemData item = new ItemData(c.plateId, c);
                m_cbCar.Items.Add(item);
                if (m_job.car != null && m_job.car.id == c.id)
                    m_cbCar.SelectedItem = item;
            }
            IList<Employee> myWorkers = ToyotaService.Instance.GetMyWorkers();
            foreach (Employee e in myWorkers)
            {
                if (e.role == EmployeeRole.Worker || (e.role == EmployeeRole.Manager && e.manager != null))
                {
                    ItemData item = new ItemData(e.name, e);
                    m_cbWorker.Items.Add(item);
                    if (m_job.worker != null && m_job.worker.id == e.id)
                        m_cbWorker.SelectedItem = item;
                }
            }

            if (m_job.id != null)
            {
                m_jobId.Text = m_job.id;
                m_cbStatus.SelectedText = m_job.status.ToString();
                m_cbPriority.SelectedText = m_job.priority.ToString();
                if (myCars.Count == 0)
                {
                    ItemData item = new ItemData(m_job.car.plateId, m_job.car);
                    m_cbCar.Items.Add(item);
                    m_cbCar.SelectedItem = item;
                }
                if (myWorkers.Count == 0 && m_job.worker != null)
                {
                    ItemData item = new ItemData(m_job.worker.name, m_job.worker);
                    m_cbWorker.Items.Add(item);
                    m_cbWorker.SelectedItem = item;
                }

                m_cbJobType.SelectedText = m_job.type.ToString();
                m_tbHistory.Text = m_job.description;
                m_tbDesc.Text = "";
            }
        }

        private void m_btnSave_Click(object sender, EventArgs e)
        {
            if (m_cbOutlet.SelectedItem == null)
            {
                m_cbOutlet.Focus();
                return;
            }
            if (m_cbJobType.Text.Length == 0)
            {
                m_cbJobType.Focus();
                return;
            }

            if (m_cbPriority.Text.Length == 0)
            {
                m_cbPriority.Focus();
                return;
            }

            if (m_cbCar.SelectedItem == null)
            {
                m_cbCar.Focus();
                return;
            }

            //collect data
            m_job.outlet = (Outlet)((ItemData)m_cbOutlet.SelectedItem).Value;
            if (m_cbStatus.Text.Length > 0)
                m_job.status = (JobStatus)Enum.Parse(typeof(JobStatus), m_cbStatus.Text);
            else
                m_job.status = JobStatus.Reported;

            m_job.priority = (JobPriority)Enum.Parse(typeof(JobPriority), m_cbPriority.Text);
            m_job.car = (Car)((ItemData)m_cbCar.SelectedItem).Value;
            if (m_cbWorker.SelectedItem != null)
                m_job.worker = (Employee)((ItemData)m_cbWorker.SelectedItem).Value;
            m_job.type = (JobType)Enum.Parse(typeof(JobType), m_cbJobType.Text);
            m_job.description = m_tbDesc.Text;

            if (m_job.id == null)
                ToyotaService.Instance.CreateJob(m_job);
            else
                ToyotaService.Instance.UpdateJob(m_job);

            DialogResult = System.Windows.Forms.DialogResult.OK;
        }

    }
}
