﻿namespace ToyotaRSS.Views
{
    partial class StatisticForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_userList = new System.Windows.Forms.DataGridView();
            this.m_btnOK = new System.Windows.Forms.Button();
            this.m_totalLabel = new System.Windows.Forms.Label();
            this.cManager = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cWorker = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.m_userList)).BeginInit();
            this.SuspendLayout();
            // 
            // m_userList
            // 
            this.m_userList.AllowUserToAddRows = false;
            this.m_userList.AllowUserToDeleteRows = false;
            this.m_userList.BackgroundColor = System.Drawing.SystemColors.Control;
            this.m_userList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.m_userList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cManager,
            this.cWorker,
            this.cName});
            this.m_userList.Location = new System.Drawing.Point(0, 58);
            this.m_userList.Margin = new System.Windows.Forms.Padding(4);
            this.m_userList.MultiSelect = false;
            this.m_userList.Name = "m_userList";
            this.m_userList.RowHeadersVisible = false;
            this.m_userList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.m_userList.Size = new System.Drawing.Size(440, 247);
            this.m_userList.TabIndex = 0;
            // 
            // m_btnOK
            // 
            this.m_btnOK.Location = new System.Drawing.Point(181, 324);
            this.m_btnOK.Margin = new System.Windows.Forms.Padding(4);
            this.m_btnOK.Name = "m_btnOK";
            this.m_btnOK.Size = new System.Drawing.Size(95, 31);
            this.m_btnOK.TabIndex = 1;
            this.m_btnOK.Text = "OK";
            this.m_btnOK.UseVisualStyleBackColor = true;
            // 
            // m_totalLabel
            // 
            this.m_totalLabel.AutoSize = true;
            this.m_totalLabel.Location = new System.Drawing.Point(10, 18);
            this.m_totalLabel.Name = "m_totalLabel";
            this.m_totalLabel.Size = new System.Drawing.Size(49, 18);
            this.m_totalLabel.TabIndex = 2;
            this.m_totalLabel.Text = "Total: ";
            // 
            // cManager
            // 
            this.cManager.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.cManager.FillWeight = 146.4698F;
            this.cManager.HeaderText = "Manager";
            this.cManager.MinimumWidth = 110;
            this.cManager.Name = "cManager";
            this.cManager.ReadOnly = true;
            // 
            // cWorker
            // 
            this.cWorker.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.cWorker.HeaderText = "Worker";
            this.cWorker.MinimumWidth = 170;
            this.cWorker.Name = "cWorker";
            this.cWorker.ReadOnly = true;
            this.cWorker.Width = 170;
            // 
            // cName
            // 
            this.cName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.cName.FillWeight = 51.48939F;
            this.cName.HeaderText = "Unresolved Jobs";
            this.cName.MinimumWidth = 150;
            this.cName.Name = "cName";
            this.cName.ReadOnly = true;
            // 
            // StatisticForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(440, 362);
            this.Controls.Add(this.m_totalLabel);
            this.Controls.Add(this.m_btnOK);
            this.Controls.Add(this.m_userList);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "StatisticForm";
            this.Text = "Employees";
            ((System.ComponentModel.ISupportInitialize)(this.m_userList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView m_userList;
        private System.Windows.Forms.Button m_btnOK;
        private System.Windows.Forms.Label m_totalLabel;
        private System.Windows.Forms.DataGridViewTextBoxColumn cManager;
        private System.Windows.Forms.DataGridViewTextBoxColumn cWorker;
        private System.Windows.Forms.DataGridViewTextBoxColumn cName;
    }
}