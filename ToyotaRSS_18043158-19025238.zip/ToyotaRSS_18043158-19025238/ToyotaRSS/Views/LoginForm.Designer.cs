﻿namespace ToyotaRSS.Views
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.m_tbUser = new System.Windows.Forms.TextBox();
            this.m_tbPassword = new System.Windows.Forms.TextBox();
            this.m_btnSignin = new System.Windows.Forms.Button();
            this.m_btnSignup = new System.Windows.Forms.Button();
            this.m_errMsg = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 38);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "User ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 79);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Password:";
            // 
            // m_tbUser
            // 
            this.m_tbUser.Location = new System.Drawing.Point(133, 34);
            this.m_tbUser.Margin = new System.Windows.Forms.Padding(4);
            this.m_tbUser.Name = "m_tbUser";
            this.m_tbUser.Size = new System.Drawing.Size(199, 22);
            this.m_tbUser.TabIndex = 2;
            // 
            // m_tbPassword
            // 
            this.m_tbPassword.Location = new System.Drawing.Point(133, 75);
            this.m_tbPassword.Margin = new System.Windows.Forms.Padding(4);
            this.m_tbPassword.Name = "m_tbPassword";
            this.m_tbPassword.PasswordChar = '*';
            this.m_tbPassword.Size = new System.Drawing.Size(199, 22);
            this.m_tbPassword.TabIndex = 3;
            // 
            // m_btnSignin
            // 
            this.m_btnSignin.Location = new System.Drawing.Point(244, 133);
            this.m_btnSignin.Margin = new System.Windows.Forms.Padding(4);
            this.m_btnSignin.Name = "m_btnSignin";
            this.m_btnSignin.Size = new System.Drawing.Size(89, 30);
            this.m_btnSignin.TabIndex = 4;
            this.m_btnSignin.Text = "Sign In";
            this.m_btnSignin.UseVisualStyleBackColor = true;
            this.m_btnSignin.Click += new System.EventHandler(this.m_btnSignin_Click);
            // 
            // m_btnSignup
            // 
            this.m_btnSignup.Enabled = false;
            this.m_btnSignup.Location = new System.Drawing.Point(135, 133);
            this.m_btnSignup.Margin = new System.Windows.Forms.Padding(4);
            this.m_btnSignup.Name = "m_btnSignup";
            this.m_btnSignup.Size = new System.Drawing.Size(89, 30);
            this.m_btnSignup.TabIndex = 5;
            this.m_btnSignup.Text = "Sign Up";
            this.m_btnSignup.UseVisualStyleBackColor = true;
            // 
            // m_errMsg
            // 
            this.m_errMsg.AutoSize = true;
            this.m_errMsg.ForeColor = System.Drawing.Color.Red;
            this.m_errMsg.Location = new System.Drawing.Point(100, 108);
            this.m_errMsg.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.m_errMsg.Name = "m_errMsg";
            this.m_errMsg.Size = new System.Drawing.Size(0, 16);
            this.m_errMsg.TabIndex = 6;
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(408, 176);
            this.Controls.Add(this.m_errMsg);
            this.Controls.Add(this.m_btnSignup);
            this.Controls.Add(this.m_btnSignin);
            this.Controls.Add(this.m_tbPassword);
            this.Controls.Add(this.m_tbUser);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "LoginForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Toyota Repair Service";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox m_tbUser;
        private System.Windows.Forms.TextBox m_tbPassword;
        private System.Windows.Forms.Button m_btnSignin;
        private System.Windows.Forms.Button m_btnSignup;
        private System.Windows.Forms.Label m_errMsg;
    }
}

