﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ToyotaRSS.Controller;
using ToyotaRSS.Security;

namespace ToyotaRSS.Views
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            m_tbUser.Focus();
            m_tbUser.Text = "E1012";
        }

        private void m_btnSignin_Click(object sender, EventArgs e)
        {
            try
            {
                LogonManager.instance.Login(m_tbUser.Text.Trim(), this.m_tbPassword.Text.Trim());
                Dispose();
            }
            catch(Exception ex)
            {
                m_errMsg.Text = ex.Message;
                m_tbUser.Focus();
            }
        }
    }
}
