﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ToyotaRSS.Models;

namespace ToyotaRSS.Views
{
    public partial class StatisticForm : Form
    {
        public StatisticForm(IList<JobStatistic> jobStats)
        {
            InitializeComponent();
            m_btnOK.DialogResult = DialogResult.Cancel;

            int total = 0;
            foreach (JobStatistic js in jobStats)
            {
                m_userList.Rows.Add(new string[]{
                    js.manager.name,
                    string.Format("({0}) {1}", js.worker.id, js.worker.name),
                    ""+js.openJobs
                });
                total += js.openJobs;
            }

            m_totalLabel.Text = string.Format("Total: {0} workers, {1} open jobs", jobStats.Count, total);
        }
    }
}
