﻿namespace ToyotaRSS.Views
{
    partial class HomeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomeForm));
            this.m_userName = new System.Windows.Forms.Label();
            this.m_jobsView = new System.Windows.Forms.DataGridView();
            this.cNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cJobId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cPriority = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cCar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cOutlet = new System.Windows.Forms.DataGridViewLinkColumn();
            this.cType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cReportedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cCustomer = new System.Windows.Forms.DataGridViewLinkColumn();
            this.cWorker = new System.Windows.Forms.DataGridViewLinkColumn();
            this.cDateReported = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.m_btnNew = new System.Windows.Forms.Button();
            this.m_btnEdit = new System.Windows.Forms.Button();
            this.m_btnExit = new System.Windows.Forms.Button();
            this.m_cbQueryStates = new System.Windows.Forms.ComboBox();
            this.m_cbQueryEmployee = new System.Windows.Forms.ComboBox();
            this.m_cbQueryCars = new System.Windows.Forms.ComboBox();
            this.m_btnSearch = new System.Windows.Forms.Button();
            this.m_btnViewWorkers = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.m_jobsView)).BeginInit();
            this.SuspendLayout();
            // 
            // m_userName
            // 
            this.m_userName.AutoSize = true;
            this.m_userName.Location = new System.Drawing.Point(510, 7);
            this.m_userName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 8);
            this.m_userName.Name = "m_userName";
            this.m_userName.Padding = new System.Windows.Forms.Padding(2, 1, 8, 1);
            this.m_userName.Size = new System.Drawing.Size(93, 24);
            this.m_userName.TabIndex = 1;
            this.m_userName.Text = "User Name";
            this.m_userName.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.m_userName.UseCompatibleTextRendering = true;
            // 
            // m_jobsView
            // 
            this.m_jobsView.AllowUserToAddRows = false;
            this.m_jobsView.AllowUserToDeleteRows = false;
            this.m_jobsView.AllowUserToOrderColumns = true;
            this.m_jobsView.BackgroundColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.m_jobsView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.m_jobsView.ColumnHeadersHeight = 32;
            this.m_jobsView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cNo,
            this.cJobId,
            this.cPriority,
            this.cCar,
            this.cOutlet,
            this.cType,
            this.cStatus,
            this.cReportedBy,
            this.cCustomer,
            this.cWorker,
            this.cDateReported});
            this.m_jobsView.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.m_jobsView.Location = new System.Drawing.Point(1, 84);
            this.m_jobsView.MultiSelect = false;
            this.m_jobsView.Name = "m_jobsView";
            this.m_jobsView.ReadOnly = true;
            this.m_jobsView.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.m_jobsView.RowHeadersVisible = false;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.LightSkyBlue;
            this.m_jobsView.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.m_jobsView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.m_jobsView.Size = new System.Drawing.Size(1310, 639);
            this.m_jobsView.TabIndex = 2;
            this.m_jobsView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.m_jobsView_CellContentClick);
            this.m_jobsView.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.m_jobsView_MouseDoubleClick);
            // 
            // cNo
            // 
            this.cNo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.cNo.FillWeight = 279.1878F;
            this.cNo.Frozen = true;
            this.cNo.HeaderText = "No.";
            this.cNo.Name = "cNo";
            this.cNo.ReadOnly = true;
            this.cNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.cNo.Width = 50;
            // 
            // cJobId
            // 
            this.cJobId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.cJobId.FillWeight = 82.08122F;
            this.cJobId.HeaderText = "Job ID";
            this.cJobId.Name = "cJobId";
            this.cJobId.ReadOnly = true;
            this.cJobId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // cPriority
            // 
            this.cPriority.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.cPriority.FillWeight = 82.08122F;
            this.cPriority.HeaderText = "Priority";
            this.cPriority.Name = "cPriority";
            this.cPriority.ReadOnly = true;
            this.cPriority.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // cCar
            // 
            this.cCar.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.cCar.FillWeight = 82.08122F;
            this.cCar.HeaderText = "Car";
            this.cCar.Name = "cCar";
            this.cCar.ReadOnly = true;
            // 
            // cOutlet
            // 
            this.cOutlet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.cOutlet.FillWeight = 82.08122F;
            this.cOutlet.HeaderText = "Outlet";
            this.cOutlet.Name = "cOutlet";
            this.cOutlet.ReadOnly = true;
            this.cOutlet.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.cOutlet.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // cType
            // 
            this.cType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.cType.FillWeight = 82.08122F;
            this.cType.HeaderText = "Type";
            this.cType.Name = "cType";
            this.cType.ReadOnly = true;
            this.cType.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // cStatus
            // 
            this.cStatus.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.cStatus.FillWeight = 82.08122F;
            this.cStatus.HeaderText = "Status";
            this.cStatus.Name = "cStatus";
            this.cStatus.ReadOnly = true;
            this.cStatus.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // cReportedBy
            // 
            this.cReportedBy.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.cReportedBy.FillWeight = 82.08122F;
            this.cReportedBy.HeaderText = "Reported By";
            this.cReportedBy.Name = "cReportedBy";
            this.cReportedBy.ReadOnly = true;
            // 
            // cCustomer
            // 
            this.cCustomer.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.cCustomer.FillWeight = 82.08122F;
            this.cCustomer.HeaderText = "Customer";
            this.cCustomer.Name = "cCustomer";
            this.cCustomer.ReadOnly = true;
            // 
            // cWorker
            // 
            this.cWorker.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.cWorker.FillWeight = 82.08122F;
            this.cWorker.HeaderText = "Worker";
            this.cWorker.Name = "cWorker";
            this.cWorker.ReadOnly = true;
            // 
            // cDateReported
            // 
            this.cDateReported.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.cDateReported.FillWeight = 82.08122F;
            this.cDateReported.HeaderText = "Reported Date";
            this.cDateReported.Name = "cDateReported";
            this.cDateReported.ReadOnly = true;
            this.cDateReported.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.cDateReported.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // m_btnNew
            // 
            this.m_btnNew.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("m_btnNew.BackgroundImage")));
            this.m_btnNew.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.m_btnNew.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.m_btnNew.FlatAppearance.BorderSize = 0;
            this.m_btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.m_btnNew.Location = new System.Drawing.Point(1, 3);
            this.m_btnNew.Margin = new System.Windows.Forms.Padding(0);
            this.m_btnNew.Name = "m_btnNew";
            this.m_btnNew.Size = new System.Drawing.Size(40, 32);
            this.m_btnNew.TabIndex = 4;
            this.m_btnNew.UseVisualStyleBackColor = true;
            this.m_btnNew.Click += new System.EventHandler(this.m_btnNew_Click);
            // 
            // m_btnEdit
            // 
            this.m_btnEdit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("m_btnEdit.BackgroundImage")));
            this.m_btnEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.m_btnEdit.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.m_btnEdit.FlatAppearance.BorderSize = 0;
            this.m_btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.m_btnEdit.Location = new System.Drawing.Point(45, 3);
            this.m_btnEdit.Margin = new System.Windows.Forms.Padding(0);
            this.m_btnEdit.Name = "m_btnEdit";
            this.m_btnEdit.Size = new System.Drawing.Size(42, 32);
            this.m_btnEdit.TabIndex = 5;
            this.m_btnEdit.UseVisualStyleBackColor = true;
            this.m_btnEdit.Click += new System.EventHandler(this.m_btnEdit_Click);
            // 
            // m_btnExit
            // 
            this.m_btnExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("m_btnExit.BackgroundImage")));
            this.m_btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.m_btnExit.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.m_btnExit.FlatAppearance.BorderSize = 0;
            this.m_btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.m_btnExit.Location = new System.Drawing.Point(1265, 3);
            this.m_btnExit.Margin = new System.Windows.Forms.Padding(0);
            this.m_btnExit.Name = "m_btnExit";
            this.m_btnExit.Size = new System.Drawing.Size(44, 32);
            this.m_btnExit.TabIndex = 7;
            this.m_btnExit.UseVisualStyleBackColor = true;
            this.m_btnExit.Click += new System.EventHandler(this.m_btnExit_Click_1);
            // 
            // m_cbQueryStates
            // 
            this.m_cbQueryStates.FormattingEnabled = true;
            this.m_cbQueryStates.Items.AddRange(new object[] {
            "All",
            "Resolved",
            "Unresolved"});
            this.m_cbQueryStates.Location = new System.Drawing.Point(2, 50);
            this.m_cbQueryStates.Name = "m_cbQueryStates";
            this.m_cbQueryStates.Size = new System.Drawing.Size(118, 26);
            this.m_cbQueryStates.TabIndex = 9;
            // 
            // m_cbQueryEmployee
            // 
            this.m_cbQueryEmployee.FormattingEnabled = true;
            this.m_cbQueryEmployee.Location = new System.Drawing.Point(125, 50);
            this.m_cbQueryEmployee.Name = "m_cbQueryEmployee";
            this.m_cbQueryEmployee.Size = new System.Drawing.Size(142, 26);
            this.m_cbQueryEmployee.TabIndex = 10;
            // 
            // m_cbQueryCars
            // 
            this.m_cbQueryCars.FormattingEnabled = true;
            this.m_cbQueryCars.Location = new System.Drawing.Point(273, 50);
            this.m_cbQueryCars.Name = "m_cbQueryCars";
            this.m_cbQueryCars.Size = new System.Drawing.Size(126, 26);
            this.m_cbQueryCars.TabIndex = 11;
            // 
            // m_btnSearch
            // 
            this.m_btnSearch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("m_btnSearch.BackgroundImage")));
            this.m_btnSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.m_btnSearch.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.m_btnSearch.FlatAppearance.BorderSize = 0;
            this.m_btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.m_btnSearch.Location = new System.Drawing.Point(403, 50);
            this.m_btnSearch.Margin = new System.Windows.Forms.Padding(0);
            this.m_btnSearch.Name = "m_btnSearch";
            this.m_btnSearch.Size = new System.Drawing.Size(30, 26);
            this.m_btnSearch.TabIndex = 12;
            this.m_btnSearch.UseVisualStyleBackColor = true;
            this.m_btnSearch.Click += new System.EventHandler(this.m_btnSearch_Click);
            // 
            // m_btnViewWorkers
            // 
            this.m_btnViewWorkers.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("m_btnViewWorkers.BackgroundImage")));
            this.m_btnViewWorkers.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.m_btnViewWorkers.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.m_btnViewWorkers.FlatAppearance.BorderSize = 0;
            this.m_btnViewWorkers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.m_btnViewWorkers.Location = new System.Drawing.Point(104, 3);
            this.m_btnViewWorkers.Margin = new System.Windows.Forms.Padding(0);
            this.m_btnViewWorkers.Name = "m_btnViewWorkers";
            this.m_btnViewWorkers.Size = new System.Drawing.Size(42, 32);
            this.m_btnViewWorkers.TabIndex = 13;
            this.m_btnViewWorkers.UseVisualStyleBackColor = true;
            this.m_btnViewWorkers.Click += new System.EventHandler(this.m_btnViewWorkers_Click);
            // 
            // HomeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1313, 724);
            this.Controls.Add(this.m_btnViewWorkers);
            this.Controls.Add(this.m_btnSearch);
            this.Controls.Add(this.m_cbQueryCars);
            this.Controls.Add(this.m_cbQueryEmployee);
            this.Controls.Add(this.m_cbQueryStates);
            this.Controls.Add(this.m_btnExit);
            this.Controls.Add(this.m_btnEdit);
            this.Controls.Add(this.m_btnNew);
            this.Controls.Add(this.m_jobsView);
            this.Controls.Add(this.m_userName);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "HomeForm";
            this.Padding = new System.Windows.Forms.Padding(4);
            this.Text = "Toyota Repair Services - My Jobs";
            this.Load += new System.EventHandler(this.HomeForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.m_jobsView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label m_userName;
        private System.Windows.Forms.DataGridView m_jobsView;
        private System.Windows.Forms.DataGridViewTextBoxColumn cNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn cJobId;
        private System.Windows.Forms.DataGridViewTextBoxColumn cPriority;
        private System.Windows.Forms.DataGridViewTextBoxColumn cCar;
        private System.Windows.Forms.DataGridViewLinkColumn cOutlet;
        private System.Windows.Forms.DataGridViewTextBoxColumn cType;
        private System.Windows.Forms.DataGridViewTextBoxColumn cStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn cReportedBy;
        private System.Windows.Forms.DataGridViewLinkColumn cCustomer;
        private System.Windows.Forms.DataGridViewLinkColumn cWorker;
        private System.Windows.Forms.DataGridViewTextBoxColumn cDateReported;
        private System.Windows.Forms.Button m_btnNew;
        private System.Windows.Forms.Button m_btnEdit;
        private System.Windows.Forms.Button m_btnExit;
        private System.Windows.Forms.ComboBox m_cbQueryStates;
        private System.Windows.Forms.ComboBox m_cbQueryEmployee;
        private System.Windows.Forms.ComboBox m_cbQueryCars;
        private System.Windows.Forms.Button m_btnSearch;
        private System.Windows.Forms.Button m_btnViewWorkers;
    }
}