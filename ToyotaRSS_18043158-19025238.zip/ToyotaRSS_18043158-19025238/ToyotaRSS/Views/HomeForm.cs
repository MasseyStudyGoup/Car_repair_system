﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ToyotaRSS.Controller;
using ToyotaRSS.Models;
using ToyotaRSS.Security;

namespace ToyotaRSS.Views
{
    public partial class HomeForm : Form
    {
        private Dictionary<string, Job> m_myJobs = new Dictionary<string, Job>();
        public HomeForm()
        {
            InitializeComponent();
            m_jobsView.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(
                this.m_jobsView_RowPrePaint);

            m_cbQueryStates.SelectedIndex = 0;

            m_cbQueryCars.Items.Add(new ItemData("All Cars", ""));
            m_cbQueryCars.SelectedIndex = 0;

            Employee user = LogonManager.instance.CurrentEmployee;
            if (user != null)
            {
                if (user.role == EmployeeRole.Worker)
                {
                    m_btnNew.Enabled = false;
                    m_btnViewWorkers.Visible = false;
                }
            }

            if (LogonManager.instance.CurrentCustomer != null)
                m_btnViewWorkers.Visible = false;
        }

        private void m_btnExit_Click_1(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void m_jobsView_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            string priority = m_jobsView.Rows[e.RowIndex].Cells[2].Value.ToString();
            string status = m_jobsView.Rows[e.RowIndex].Cells[6].Value.ToString();
            if (status != JobStatus.Closed.ToString())
            {
                if (priority == JobPriority.Critical.ToString())
                    m_jobsView.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Red;
                else if (priority == JobPriority.Major.ToString())
                    m_jobsView.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.Yellow;
            }
        }

        private void HomeForm_Load(object sender, EventArgs e)
        {
            m_userName.Text = "Welcome " + LogonManager.instance.CurrentUser + "!";
            IList<Job> myJobs = ToyotaService.Instance.GetMyJobs();

            RefreshJobList(myJobs);

            if (LogonManager.instance.CurrentCustomer != null ||
                LogonManager.instance.CurrentEmployee.role == EmployeeRole.Worker)
            {
                m_cbQueryEmployee.Enabled = false;
            }
            else
            {
                m_cbQueryEmployee.Items.Add(new ItemData("All Employees", ""));
                m_cbQueryEmployee.SelectedIndex = 0;
                IList<Employee> workers = ToyotaService.Instance.GetMyWorkers();
                foreach (Employee worker in workers)
                {
                    //filter out admin, help desk and general manager
                    if(worker.role == EmployeeRole.Worker || (worker.role == EmployeeRole.Manager && worker.manager != null))
                        m_cbQueryEmployee.Items.Add(new ItemData(worker.name, worker.id));
                }
            }

            IList<Car> cars = ToyotaService.Instance.GetMyCars();
            foreach (Car car in cars)
                m_cbQueryCars.Items.Add(new ItemData(car.plateId, car.id));
        }

        private void RefreshJobList(IList<Job> jobs)
        {
            m_myJobs.Clear();
            m_jobsView.Rows.Clear();

            int count = 0;
            foreach (Job job in jobs)
            {
                count++;
                m_myJobs.Add(job.id, job);
                m_jobsView.Rows.Add(new string[]{""+count,
                    job.id,
                    job.priority.ToString(),
                    job.car.plateId,
                    job.outlet.name,
                    job.type.ToString(),
                    job.status.ToString(),
                    (job.createdBy == null)?job.customer.name:job.createdBy.name,
                    job.customer.name,
                    (job.worker == null)?"":job.worker.name,
                    job.reportedDate.ToString("yyyy-MM-dd HH:mm:ss")
                });
            }
        }
        private void m_jobsView_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            EditJob();
        }

        private void m_btnEdit_Click(object sender, EventArgs e)
        {
            EditJob();
        }

        private void m_jobsView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = m_jobsView.SelectedRows[0];
            string jobId = (string)row.Cells[1].Value;
            int cell = e.ColumnIndex;

        }

        private void EditJob()
        {
            DataGridViewRow row = m_jobsView.SelectedRows[0];
            string jobId = (string)row.Cells[1].Value;
            Job job = m_myJobs[jobId];
            if (job != null)
            {
                JobEditor jobDialog = new JobEditor(job);
                if (jobDialog.ShowDialog() == DialogResult.OK)
                {
                    m_btnSearch_Click(m_btnSearch, null);
                }
            }
        }

        private void m_btnSearch_Click(object sender, EventArgs e)
        {
            string states = m_cbQueryStates.SelectedItem.ToString();
            string employeeId = "";
            if (m_cbQueryEmployee.Enabled)
                employeeId = ((ItemData)m_cbQueryEmployee.SelectedItem).Value.ToString();
            string carId = ((ItemData)m_cbQueryCars.SelectedItem).Value.ToString();

            IList<Job> myJobs = ToyotaService.Instance.GetMyJobs(states, carId, employeeId);
            RefreshJobList(myJobs);
        }

        private void m_btnNew_Click(object sender, EventArgs e)
        {
            JobEditor jobDialog = new JobEditor();
            if (jobDialog.ShowDialog() == DialogResult.OK)
            {
                m_btnSearch_Click(m_btnSearch, null);
            }
        }

        private void m_btnViewWorkers_Click(object sender, EventArgs e)
        {
            StatisticForm userDialog = new StatisticForm(ToyotaService.Instance.SummarizeJobs());
            userDialog.ShowDialog();
        }
    }
}
