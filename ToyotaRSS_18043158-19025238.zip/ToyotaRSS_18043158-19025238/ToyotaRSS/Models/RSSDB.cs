﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SQLite;
using ToyotaRSS.Security;


namespace ToyotaRSS.Models
{
    public class RSSDB
    {
        private static RSSDB _instance = new RSSDB();
        private static string SQL_SELECT_BY_ID_FMT = "SELECT * FROM {0} WHERE id='{1}'";
        private static string SQL_UPDATE_BY_ID_FMT = "UPDATE {0} SET {1} WHERE id='{2}'";
        private static string SQL_COLUMN_VALUE_FMT = "{0}='{1}'";

        SQLiteConnection m_dbConnection;
        String m_connectString = "Data Source=" + AppDomain.CurrentDomain.BaseDirectory + "ToyotaRSS.db";

        private Dictionary<string, Outlet> m_outletDict = new Dictionary<string, Outlet>(4);
        private Dictionary<string, Car> m_carDict = new Dictionary<string, Car>();
        private Dictionary<string, Employee> m_managerDict = new Dictionary<string, Employee>();

        private RSSDB()
        {
            m_dbConnection = new SQLiteConnection(m_connectString);
        }

        public static RSSDB instance
        {
            get => _instance;
        }

        
        public void InitDB()
        {
            if (GetTables().Count == 0)
            {
                string contents = File.ReadAllText(@"CreateTables.sql");
                string[] initSqls = contents.Trim().Split(';');
                CreateDB(initSqls);
            }
            //load outlets
            GetOutlet(null);
        }

        private void OpenDB()
        {
            if (m_dbConnection.State != System.Data.ConnectionState.Open)
                m_dbConnection.Open();
        }

        private void CloseDB()
        {
            //m_dbConnection.Close();
        }

        private IList<string> GetTables()
        {
            OpenDB();
            IList<string> tables = new List<string>();
            using (SQLiteCommand cmd = m_dbConnection.CreateCommand())
            {
                cmd.CommandText = "SELECT name FROM sqlite_master WHERE type = 'table' ORDER BY name";
                using (SQLiteDataReader rdr = cmd.ExecuteReader())
                {
                    while (rdr.Read())
                    {
                        tables.Add(rdr.GetString(0));
                    }
                }
            }
            CloseDB();

            return tables;

        }
        private void CreateDB(string[] initSqls)
        {
            OpenDB();
            try
            {
                SQLiteCommand createCmd = m_dbConnection.CreateCommand();
                foreach (string sql in initSqls)
                {
                    //ignore comments
                    string cmd = sql.Trim();
                    if (cmd.StartsWith("--") || cmd.Length == 0)
                        continue;
                    //Console.WriteLine(cmd);
                    createCmd.CommandText = cmd;
                    createCmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                Console.Write(e.StackTrace);
            }
            finally
            {
                CloseDB();
            }

            IList<string> tables = GetTables();
            Console.WriteLine("The following tables are created:");
            foreach (string t in tables)
                Console.WriteLine(t);
        }

        private static int[] GetColumnIndex(SQLiteDataReader reader, string[] columns)
        {
            int[] ids = new int[columns.Length];
            for (int i = 0; i < columns.Length; i++)
            {
                ids[i] = reader.GetOrdinal(columns[i]);
            }

            return ids;
        }

        private static string[] ReadRow(SQLiteDataReader reader, int[] index)
        {
            string[] values = new string[index.Length];
            for (int i = 0; i < index.Length; i++)
            {
                values[i] = reader.GetString(index[i]);
            }

            return values;
        }

        public Employee GetManager(string id)
        {
            if (m_managerDict.Count == 0)
            {
                OpenDB();
                using (SQLiteCommand cmd = m_dbConnection.CreateCommand())
                {
                    cmd.CommandText = string.Format("SELECT * FROM {0} WHERE role = '{1}'", Employee.TABLE_NAME, EmployeeRole.Manager.ToString());
                    using (SQLiteDataReader reader = cmd.ExecuteReader())
                    {
                        int[] ids = GetColumnIndex(reader, Employee.COLUMNS);
                        while (reader.Read())
                        {
                            string[] values = ReadRow(reader, ids);
                            Employee e = Employee.Build(values);
                            m_managerDict.Add(e.id.ToUpper(), e);
                        }
                    }
                }
                CloseDB();
            }

            return (id == null) ? null : m_managerDict[id.ToUpper()];

        }

        public Outlet GetOutlet(string id)
        {
            if (m_outletDict.Count == 0)
            {
                OpenDB();
                using (SQLiteCommand cmd = m_dbConnection.CreateCommand())
                {
                    cmd.CommandText = string.Format("SELECT * FROM {0} ORDER BY name", Outlet.TABLE_NAME);
                    using (SQLiteDataReader reader = cmd.ExecuteReader())
                    {
                        int[] ids = GetColumnIndex(reader, Outlet.COLUMNS);
                        while (reader.Read())
                        {
                            string[] values = ReadRow(reader, ids);
                            Outlet o = Outlet.Build(values);
                            m_outletDict.Add(o.id.ToUpper(), o);
                        }
                    }
                }
                CloseDB();
            }

            return (id == null)?null:m_outletDict[id.ToUpper()];
        }

        public IList<Outlet> QueryOutlets()
        {
            GetOutlet(null);
            return m_outletDict.Values.ToList<Outlet>();
        }

        public IList<Employee> AllEmployees()
        {
            OpenDB();
            IList<Employee> elist = new List<Employee>();
            using (SQLiteCommand cmd = m_dbConnection.CreateCommand())
            {
                cmd.CommandText = string.Format("SELECT * FROM {0} ORDER BY name", Employee.TABLE_NAME);
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    int[] ids = GetColumnIndex(reader, Employee.COLUMNS);
                    while (reader.Read())
                    {
                        string[] values = ReadRow(reader, ids);
                        Employee e = Employee.Build(values);
                        if (e.manager != null)
                            e.manager = GetManager(e.manager.id);
                        elist.Add(e);
                    }
                }
            }
            CloseDB();
            return elist;
        }

        public IList<Employee> GetEmployeesByManager(string managerId)
        {
            OpenDB();
            IList<Employee> elist = new List<Employee>();
            using (SQLiteCommand cmd = m_dbConnection.CreateCommand())
            {
                cmd.CommandText = string.Format("SELECT * FROM {0} WHERE manager_id = '{1}'", Employee.TABLE_NAME, managerId);
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    Employee manager = GetManager(managerId);
                    int[] ids = GetColumnIndex(reader, Employee.COLUMNS);
                    while (reader.Read())
                    {
                        string[] values = ReadRow(reader, ids);
                        Employee e = Employee.Build(values);
                        e.manager = manager;
                        elist.Add(e);
                    }
                }
            }
            CloseDB();
            return elist;
        }

        public Employee GetEmployee(string id)
        {
            OpenDB();
            Employee e = null;
            using (SQLiteCommand cmd = m_dbConnection.CreateCommand())
            {
                cmd.CommandText = string.Format(SQL_SELECT_BY_ID_FMT, Employee.TABLE_NAME, id.ToUpper());
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    int[] ids = GetColumnIndex(reader, Employee.COLUMNS);
                    while (reader.Read())
                    {
                        string[] values = ReadRow(reader, ids);
                        e = Employee.Build(values);
                    }
                }
            }
            CloseDB();
            return e;
        }

        public IList<Customer> QueryCustomer(string sql)
        {
            IList<Customer> customers = new List<Customer>();
            OpenDB();

            using (SQLiteCommand cmd = m_dbConnection.CreateCommand())
            {
                cmd.CommandText = (sql == null || sql.Length == 0)?"SELECT * FROM customer":sql;
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    int[] ids = GetColumnIndex(reader, Customer.COLUMNS);
                    while (reader.Read())
                    {
                        string[] values = ReadRow(reader, ids);
                        Customer c = Customer.Build(values);
                        customers.Add(c);
                    }
                }
            }
            CloseDB();
            return customers;
        }

        public Customer GetCustomer(string id)
        {
            OpenDB();
            Customer c = null;
            using (SQLiteCommand cmd = m_dbConnection.CreateCommand())
            {
                cmd.CommandText = string.Format(SQL_SELECT_BY_ID_FMT, Customer.TABLE_NAME, id.ToUpper());
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    int[] ids = GetColumnIndex(reader, Customer.COLUMNS);
                    while (reader.Read())
                    {
                        string[] values = ReadRow(reader, ids);
                        c = Customer.Build(values);
                    }
                }
            }
            CloseDB();
            return c;
        }

        public IList<Car> QueryCar(Boolean forceReload)
        {
            if (!forceReload && m_carDict.Count > 0)
                return m_carDict.Values.ToList<Car>();

            m_carDict.Clear();
            OpenDB();

            using (SQLiteCommand cmd = m_dbConnection.CreateCommand())
            {
                cmd.CommandText = "SELECT * FROM car ORDER BY plate_id";
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    int[] ids = GetColumnIndex(reader, Car.COLUMNS);
                    while (reader.Read())
                    {
                        string[] values = ReadRow(reader, ids);
                        Car c = Car.Build(values);
                        m_carDict.Add(c.id.ToUpper(), c);
                    }
                }
            }
            CloseDB();

            return m_carDict.Values.ToList<Car>();
        }

        public Car GetCar(string id)
        {
            if (!m_carDict.ContainsKey(id.ToUpper()))
                QueryCar(true);

            return m_carDict[id.ToUpper()];
        }

        public IList<Car> GetCarsByCustomer(string customerId)
        {
            IList<Car> cars = new List<Car>();
            IList<Car> allCars = QueryCar(false);
            foreach(Car c in allCars)
            {
                if (string.Compare(customerId, c.customer.id, true) == 0)
                    cars.Add(c);
            }
            return cars;
        }

        public IList<Job> QueryJob(string sql)
        {
            IList<Job> jobs = new List<Job>();
            OpenDB();
            
            using (SQLiteCommand cmd = m_dbConnection.CreateCommand())
            {
                cmd.CommandText = sql;
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    int[] ids = GetColumnIndex(reader, Job.COLUMNS);
                    while (reader.Read())
                    {
                        string[] values = ReadRow(reader, ids);
                        Job j = Job.Build(values);
                        if (j.car != null)
                            j.car = GetCar(j.car.id);
                        if (j.worker != null)
                            j.worker = GetEmployee(j.worker.id);
                        if (j.customer != null)
                            j.customer = GetCustomer(j.customer.id);
                        if (j.createdBy != null)
                            j.createdBy = GetEmployee(j.createdBy.id);
                        jobs.Add(j);
                    }
                }
            }
            CloseDB();

            return jobs;
        }

        public Job GetJob(string id)
        {
            Job job = null;
            OpenDB();

            using (SQLiteCommand cmd = m_dbConnection.CreateCommand())
            {
                cmd.CommandText = string.Format(SQL_SELECT_BY_ID_FMT, Job.TABLE_NAME, id);
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    int[] ids = GetColumnIndex(reader, Job.COLUMNS);
                    while (reader.Read())
                    {
                        string[] values = ReadRow(reader, ids);
                        job = Job.Build(values);
                    }
                }
            }
            CloseDB();

            return job;
        }
        private string MakeJobId(Job job)
        {
            StringBuilder sb = new StringBuilder("J");
            if (job.type == JobType.Electical)
                sb.Append("E");
            else if (job.type == JobType.Mechanical)
                sb.Append("M");
            else
                sb.Append("P");
            if (job.reportedDate == null)
                job.reportedDate = new DateTime();

            sb.Append(job.reportedDate.ToString("yyMMddHHmmss"));

            return sb.ToString();
        }

        public Job CreateJob(Job job)
        {
            if (job.id == null)
            {
                job.reportedDate = DateTime.Now;
                job.updatedDate = job.reportedDate;
                job.id = MakeJobId(job);
            }
            if (LogonManager.instance.CurrentEmployee != null)
            {
                job.createdBy = LogonManager.instance.CurrentEmployee;
            }

            if (job.car != null)
            {
                job.customer = job.car.customer;
            }

            string hist = string.Format("{0} created by {1}({2}){3}",
                job.reportedDate.ToString(BaseEntity.DATETIME_FORMAT),
                LogonManager.instance.CurrentUser,
                LogonManager.instance.CurrentUserId,
                Environment.NewLine
                );
            job.description = hist + Environment.NewLine + job.description;

            string sql = string.Format("INSERT INTO {0} ({1}) VALUES ({2})", Job.TABLE_NAME, string.Join(",", Job.COLUMNS), BaseEntity.JoinValues(job.Values));
            OpenDB();
            using (SQLiteCommand cmd = m_dbConnection.CreateCommand())
            {
                cmd.CommandText = sql;
                cmd.ExecuteNonQuery();
            }
            CloseDB();

            return job;
        }

        public Job UpdateJob(Job job)
        {
            Job origin = GetJob(job.id);
            if (origin == null)
                throw new Exception("No such Job " + job.id);
            job.updatedDate = DateTime.Now;
            StringBuilder sb = new StringBuilder();
            sb.Append(string.Format(SQL_COLUMN_VALUE_FMT, Job.C_CAR_ID, job.car.id));
            sb.Append(", ").Append(string.Format(SQL_COLUMN_VALUE_FMT, Job.C_CUSTOMER_ID, job.customer.id));
            sb.Append(", ").Append(string.Format(SQL_COLUMN_VALUE_FMT, Job.C_OUTLET_ID, job.outlet.id));
            sb.Append(", ").Append(string.Format(SQL_COLUMN_VALUE_FMT, Job.C_PRIORITY, job.priority.ToString()));
            sb.Append(", ").Append(string.Format(SQL_COLUMN_VALUE_FMT, Job.C_TYPE, job.type.ToString()));
            sb.Append(", ").Append(string.Format(SQL_COLUMN_VALUE_FMT, Job.C_WORKER_ID, (job.worker == null)?"":job.worker.id));
            sb.Append(", ").Append(string.Format(SQL_COLUMN_VALUE_FMT, Job.C_DATE_UPDATED, job.updatedDate.ToString(BaseEntity.DATETIME_FORMAT)));
            sb.Append(", ").Append(string.Format(SQL_COLUMN_VALUE_FMT, Job.C_STATUS, job.status.ToString()));
            if (origin.status != job.status && job.status == JobStatus.Closed)
            {
                job.closedDate = job.updatedDate;
                sb.Append(", ").Append(string.Format(SQL_COLUMN_VALUE_FMT, Job.C_DATE_CLOSED, job.closedDate.ToString(BaseEntity.DATETIME_FORMAT)));
            }

            //add history
            string hist = string.Format("{0} updated by {1}({2}):",
                job.updatedDate.ToString(BaseEntity.DATETIME_FORMAT),
                LogonManager.instance.CurrentUser,
                LogonManager.instance.CurrentUserId
                );
            if (job.description.Length > 0)
                hist = hist + Environment.NewLine + job.description;
            job.description = hist + Environment.NewLine + Environment.NewLine + origin.description;

            sb.Append(", ").Append(string.Format(SQL_COLUMN_VALUE_FMT, Job.C_DESC, job.description));

            string sql = string.Format(SQL_UPDATE_BY_ID_FMT, Job.TABLE_NAME, sb.ToString(), job.id);
            OpenDB();
            using (SQLiteCommand cmd = m_dbConnection.CreateCommand())
            {
                cmd.CommandText = sql;
                cmd.ExecuteNonQuery();
            }
            CloseDB();

            return job;
        }

        public IList<JobStatistic> StatisticJobs()
        {
            IList<JobStatistic> summaries = new List<JobStatistic>();
            if (m_managerDict.Count == 0)
                GetManager(null);

            OpenDB();

            using (SQLiteCommand cmd = m_dbConnection.CreateCommand())
            {
                cmd.CommandText = string.Format("SELECT COUNT(id), worker_id FROM {0} WHERE job_status <> '{1}' group by worker_id", Job.TABLE_NAME, JobStatus.Closed.ToString());
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int count = reader.GetInt32(0);
                        string workerId = reader.GetString(1);
                        Employee w = GetEmployee(workerId);
                        if (w == null)
                            continue;

                        JobStatistic js = new JobStatistic
                        {
                            openJobs = count,
                            worker = w,
                            manager = GetManager(w.manager.id)
                        };
                        summaries.Add(js);
                    }
                }
            }
            CloseDB();

            return summaries;
        }
    }
}