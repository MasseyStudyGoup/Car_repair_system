﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToyotaRSS.Models
{
    public class Customer:BaseEntity
    {
        public static string TABLE_NAME = "customer";

        public static string C_NAME = "name";
        public static string C_PASSWORD = "password";
        public static string C_EMAIL = "email";
        public static string C_ADDRESS = "address";
        public static string C_PHONE = "phone";
        public static string[] COLUMNS = { C_ID, C_NAME, C_PASSWORD, C_EMAIL, C_ADDRESS, C_PHONE, C_DESC };

        private string _name;
        private string _password;
        private string _email;
        private string _phone;
        private string _address;

        public string name
        {
            get => _name;
            set { _name = value; }
        }

        public string email
        {
            get => _email;
            set { _email = value; }
        }

        public string address
        {
            get => _address;
            set{ _address = value; }
        }

        public string phone
        {
            get => _phone;
            set{ _phone = value;}
        }

        public string password
        {
            get => _password;
            set { _password = value; }
        }

        public IList<Job> GetJobs()
        {
            return null;
        }

        public IList<Car> GetCars()
        {
            return null;
        }

        public static Customer Build(string[] values)
        {
            Customer c = new Customer();
            c.id = values[0];
            c._name = values[1];
            c._password = values[2];
            c._email = values[3];
            c._address = values[4];
            c._phone = values[5];
            c.description = values[6];

            return c;
        }
    }
}
