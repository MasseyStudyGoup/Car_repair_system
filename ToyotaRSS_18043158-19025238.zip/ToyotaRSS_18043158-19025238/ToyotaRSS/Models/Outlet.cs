﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ToyotaRSS.Models
{
    public class Outlet:BaseEntity 
    {
        public static string TABLE_NAME = "outlet";
        public static string C_NAME = "name";
        public static string C_MANAGER_ID = "manager_id";
        public static string C_ADDRESS = "address";
        public static string[] COLUMNS = { C_ID, C_NAME, C_MANAGER_ID, C_ADDRESS, C_DESC};

        private string _address;
        private string _name;
        private Employee _manager;

        public string name
        {
            get => _name;
            set { _name = value; }
        }
        public string address
        {
            get => _address;
            set { _address = value; }
        }

        public Employee manager
        {
            get => _manager;
            set { _manager = value; }
        }

        IList<Job> GetJobs()
        {
            return null;
        }

        public static string GetInsertCommand(Outlet o)
        {
            return string.Format("insert into {0} (id, name, address, description) values ('{1}', '{2}', '{3}', '{4}')", TABLE_NAME, o.id, o.name, o.address, o.description);
        }

        public static Outlet Build(string[] values)
        {
            Outlet o = new Outlet();
            o.id = values[0];
            o.name = values[1];
            o._manager = new Manager();
            o._manager.id = values[2];
            o._address = values[3];
            o.description = values[4];
            return o;
        }
    }
}