﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ToyotaRSS.Models
{
    public class Car : BaseEntity
    {
        public static string TABLE_NAME = "car";
        public static string C_CUSTOMER_ID = "customer_id";
        public static string C_PLATE_ID = "plate_id";
        public static string C_DATE_REGISTERED = "date_registered";
        public static string[] COLUMNS = { C_ID, C_PLATE_ID, C_CUSTOMER_ID, C_DATE_REGISTERED, C_DESC };

        private Customer _customer;
        private string _plateId;
        private DateTime _registerDate;

        public Customer customer
        {
            get => _customer;
            set{ _customer = value; }
        }

        public string plateId
        {
            get => _plateId;
            set { _plateId = value; }
        }

        public DateTime registerDate
        {
            get => _registerDate;
            set { _registerDate = value; }
        }

        public static Car Build(string[] values)
        {
            Car c = new Car();
            c.id = values[0];
            c._plateId = values[1];
            c._customer = new Customer() { id = values[2] };
            c._registerDate = DateTime.Parse(values[3]);
            c.description = values[4];
            return c;
        }
    }
}