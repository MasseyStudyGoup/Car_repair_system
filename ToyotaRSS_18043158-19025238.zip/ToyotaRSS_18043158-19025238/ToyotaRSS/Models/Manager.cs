﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ToyotaRSS.Models
{
    public class Manager:Employee
    {
        private IList<Worker> _workers;
        
        public void AssignJob(Job job, Worker worker)
        {

        }

        public void SetPriority(Job job, JobPriority priority)
        {

        }
    }

}