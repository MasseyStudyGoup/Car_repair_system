﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToyotaRSS.Models
{
    public class JobStatistic
    {
        private Employee _manager;
        private Employee _worker;
        private int _closed;
        private int _open;

        public Employee manager
        {
            get => _manager;
            set { _manager = value; }
        }
        public Employee worker
        {
            get => _worker;
            set { _worker = value; }
        }

        public int closedJobs
        {
            get => _closed;
            set { _closed = value; }
        }

        public int openJobs
        {
            get => _open;
            set { _open = value; }
        }
    }
}
