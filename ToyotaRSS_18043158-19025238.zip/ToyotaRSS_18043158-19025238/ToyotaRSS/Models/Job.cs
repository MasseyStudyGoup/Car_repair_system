﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToyotaRSS.Models
{
    public enum JobPriority
    {
        Critical,
        Major,
        Minor
    }

    public enum JobType
    {
        PanelBeating,
        Electical,
        Mechanical
    }

    public enum JobStatus
    {
        Reported,
        Verified,
        Assigned,
        Repairing,
        Closed
    }

    public class Job : BaseEntity
    {
        public static string TABLE_NAME = "job";

        public static string C_CAR_ID = "car_id";
        public static string C_OUTLET_ID = "outlet_id";
        public static string C_WORKER_ID = "worker_id";
        public static string C_PRIORITY = "job_priority";
        public static string C_TYPE = "job_type";
        public static string C_STATUS = "job_status";
        public static string C_CREATED_BY = "created_by";
        public static string C_CUSTOMER_ID = "customer_id";
        public static string C_DATE_CLOSED = "date_closed";
        public static string C_DATE_UPDATED = "date_updated";
        public static string C_DATE_REPORTED = "date_reported";
        public static string[] COLUMNS = { C_ID, C_CAR_ID, C_OUTLET_ID, C_PRIORITY, C_WORKER_ID, C_TYPE, C_STATUS, C_CREATED_BY, C_CUSTOMER_ID, C_DATE_CLOSED, C_DATE_UPDATED, C_DATE_REPORTED, C_DESC };

        private DateTime _dateReported;
        private DateTime _dateUpdated;
        private DateTime _dateClosed;
        private JobType _type;
        private JobPriority _priority;
        private JobStatus _status;
        private Employee _worker;
        private Employee _createdBy;
        private Car _car;
        private Outlet _outlet;
        private Customer _customer;

        public Customer customer
        {
            get => _customer;
            set { _customer = value; }
        }

        public Car car
        {
            get => _car;
            set { _car = value; }
        }

        public Outlet outlet
        {
            get => _outlet;
            set { _outlet = value; }
        }

        public Employee createdBy
        {
            get => _createdBy;
            set { _createdBy = value; }
        }

        public Employee worker
        {
            get => _worker;
            set { _worker = value; }
        }

        public JobStatus status
        {
            get => _status;
            set { _status = value; }
        }
        public JobPriority priority
        {
            get => _priority;
            set { _priority = value; }
        }
        public JobType type
        {
            get => _type;
            set { _type = value; }
        }

        public DateTime closedDate
        {
            get => _dateClosed;
            set { _dateClosed = value; }
        }

        public DateTime reportedDate
        {
            get => _dateReported;
            set { _dateReported = value; }
        }

        public DateTime updatedDate
        {
            get => _dateUpdated;
            set { _dateUpdated = value; }
        }
        
        public string[] Values
        {
            get => new string[] {id,
                car.id,
                outlet.id,
                _priority.ToString(),
                (_worker == null)?"":_worker.ToString(),
                _type.ToString(),
                _status.ToString(),
                (_createdBy == null)?"":_createdBy.id,
                _customer.id,
                (_dateClosed == null)?"":_dateClosed.ToString(DATETIME_FORMAT),
                (_dateUpdated == null)?"":_dateUpdated.ToString(DATETIME_FORMAT),
                (_dateReported == null)?"":_dateReported.ToString(DATETIME_FORMAT),
                description};
        }
        public static Job Build(string[] values)
        {
            Job j = new Job() { id = values[0] };
            j._car = new Car() { id = values[1] };
            j._outlet = RSSDB.instance.GetOutlet(values[2]);
            j._priority = (JobPriority)ToEnum(typeof(JobPriority), values[3]);
            if (values[4].Length > 0)
            {
                j._worker = new Employee() { id = values[4] };
            }

            j._type = (JobType)ToEnum(typeof(JobType), values[5]);
            j._status = (JobStatus)ToEnum(typeof(JobStatus), values[6]);
            if (values[7].Length > 0)
            {
                j._createdBy = new Employee() { id = values[7] };
            }
            j._customer = new Customer() { id = values[8] };

            if (values[9].Length > 0 )
            {
                try
                {
                    j._dateClosed = DateTime.Parse(values[9]);
                }
                catch
                {
                    j._dateClosed = DateTime.Now;
                }
            }
            if (values[10].Length > 0)
            {
                try
                {
                    j._dateUpdated = DateTime.Parse(values[10]);
                }
                catch
                {
                    j._dateUpdated = DateTime.Now;
                }
            }
            if (values[11].Length > 0)
            {
                try
                {
                    j._dateReported = DateTime.Parse(values[11]);
                }
                catch
                {
                    j._dateReported = DateTime.Now;
                }
            }
            j.description = values[12];
            return j;
        }
    }
}
