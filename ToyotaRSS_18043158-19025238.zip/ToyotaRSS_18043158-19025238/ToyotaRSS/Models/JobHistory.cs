﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ToyotaRSS.Models
{
    public class JobHistory:BaseEntity
    {
        public static string TABLE_NAME = "job_history";
        public static string C_JOB_ID = "job_id";
        public static string C_JOB_STATUS = "job_status";
        public static string C_DATE_UPDATED = "date_updated";
        public static string C_WORKER_ID = "worker_id";
        public static string[] COLUMNS = {C_ID, C_JOB_ID, C_JOB_STATUS, C_DATE_UPDATED, C_WORKER_ID, C_DESC };

        private Job _job;
        private DateTime _updateDate;
        private JobStatus _status;
        private Worker _worker;

        public JobStatus status
        {
            get => _status;
            set { _status = value; }
        }

        public DateTime updateDate
        {
            get => _updateDate;
            set { _updateDate = value; }
        }

        public Worker worker
        {
            get => _worker;
            set { _worker = value; }
        }

        public Job job
        {
            get => _job;
            set { _job = value; }
        }
    }
}