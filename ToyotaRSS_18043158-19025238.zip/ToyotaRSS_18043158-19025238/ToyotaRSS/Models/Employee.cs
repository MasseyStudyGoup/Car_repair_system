﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToyotaRSS.Models
{
    public enum EmployeeRole { Administrator, Manager, Worker, HelpDesk }

    public class Employee:BaseEntity
    {
        public static string TABLE_NAME = "employee";
        public static string C_NAME = "name";
        public static string C_PASSWORD = "password";
        public static string C_MANAGER = "manager_id";
        public static string C_OULET = "outlet_id";
        public static string C_ROLE = "role";
        public static string[] COLUMNS = {C_ID, C_NAME, C_PASSWORD, C_ROLE, C_MANAGER, C_OULET, C_DESC};

        private string _name;
        private string _password;
        private EmployeeRole _role;
        private Employee _manager;
        private Outlet _outlet;

        public string name
        {
            get => _name;
            set {_name = value;}
        }

        public string password
        {
            get => _password;
            set { _password = value; }
        }

        public Employee manager
        {
            get => _manager;
            set{ _manager = value;}
        }

        public Outlet outlet
        {
            get => _outlet;
            set{ _outlet = value; }
        }

        public EmployeeRole role
        {
            get => _role;
            set{ _role = value; }
        }

        IList<Job> GetJobs()
        {
            return null;
        }

        void SetJobStatue(Job job, JobStatus status)
        {

        }

        public static Employee Build(string[] values)
        {
            Employee e = new Employee();
            e.id = values[0];
            e._name = values[1];
            e._password = values[2];
            e._role = (EmployeeRole)ToEnum(typeof(EmployeeRole), values[3]);
            if (values[4] != null && values[4].Length > 0)
            {
                e._manager = new Manager
                {
                    id = values[4]
                };
            }
            if (values[5] != null && values[5].Length > 0)
            {
                e._outlet = new Outlet
                {
                    id = values[5]
                };
            }
            e.description = values[6];
            return e;
        }
    }
}
