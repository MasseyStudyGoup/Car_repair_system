﻿CREATE TABLE outlet (
	id	TEXT PRIMARY KEY NOT NULL,
	name TEXT NOT NULL,
	address	TEXT NOT NULL,
	manager_id	TEXT DEFAULT '',
	description	TEXT DEFAULT '',
	FOREIGN KEY(manager_id) REFERENCES employee(id)
);

CREATE TABLE employee (
	id	TEXT PRIMARY KEY NOT NULL,
	password	TEXT DEFAULT '',
	manager_id	TEXT DEFAULT '',
	name	TEXT NOT NULL,
	outlet_id	TEXT DEFAULT '',
	role	TEXT NOT NULL,
	description	TEXT DEFAULT '',
	FOREIGN KEY(manager_id) REFERENCES employee(id),
	FOREIGN KEY(outlet_id) REFERENCES outlet(id)
);

CREATE TABLE customer (
	id	TEXT PRIMARY KEY NOT NULL,
	name	TEXT NOT NULL,
	address	TEXT NOT NULL,
	email	TEXT DEFAULT '',
	phone	TEXT DEFAULT '',
	password TEXT DEFAULT '',
	description	TEXT DEFAULT ''
);

CREATE TABLE car (
	id	TEXT PRIMARY KEY NOT NULL,
	plate_id TEXT NOT NULL,
	customer_id	TEXT DEFAULT '',
	date_registered TEXT DEFAULT '',
	description	TEXT DEFAULT '',
	FOREIGN KEY(customer_id) REFERENCES customer(id)
);

CREATE TABLE job (
	id	TEXT PRIMARY KEY NOT NULL,
	job_priority TEXT NOT NULL,
	car_id	TEXT,
	outlet_id	TEXT DEFAULT '',
	job_type	TEXT NOT NULL,
	job_status	TEXT NOT NULL,
	description	TEXT DEFAULT '',
	created_by	TEXT DEFAULT '',
	customer_id	TEXT NOT NULL,
	worker_id TEXT,
	date_closed	 TEXT DEFAULT '',
	date_updated TEXT DEFAULT '',
	date_reported TEXT NOT NULL,
	FOREIGN KEY(worker_id) REFERENCES employee(id),
	FOREIGN KEY(created_by) REFERENCES employee(id),
	FOREIGN KEY(outlet_id) REFERENCES outlet(id),
	FOREIGN KEY(customer_id) REFERENCES customer(id),
	FOREIGN KEY(car_id) REFERENCES car(id)
);

CREATE TABLE job_history (
	id	TEXT PRIMARY KEY NOT NULL,
	job_id	TEXT NOT NULL,
	job_status	TEXT NOT NULL,
	date_updated TEXT NOT NULL,
	worker_id	TEXT NOT NULL,
	description	TEXT DEFAULT '',
	FOREIGN KEY(job_id) REFERENCES job(id),
	FOREIGN KEY(worker_id) REFERENCES employee(id)
);
-- add outlets;
INSERT INTO outlet (id, name, address, manager_id) values ('NZ1', 'North Shore Toyota Signatures', '14 Mairangi Bay, North Shore City', 'E0101');
INSERT INTO outlet (id, name, address, manager_id) values ('NZ2', 'Manukau Toyota Signatures', '204 Manukau Creek, Manukau City', 'E0102');
INSERT INTO outlet (id, name, address, manager_id) values ('NZ3', 'Wellington Toyota Signatures', '314 Eastmond Street, Wellington', 'E0103');
INSERT INTO outlet (id, name, address, manager_id) values ('NZ4', 'Christchurch Toyota Signatures', '314 Sycamore Street, Christchurch', 'E0104');

--add managers;
INSERT INTO employee(id, password, name, manager_id, outlet_id, role) VALUES ('E0100', 'm1234', 'Tom Anderson', '', '', 'Manager' );

INSERT INTO employee(id, password, name, manager_id, outlet_id, role) VALUES ('E0101', 'm1234', 'Mary Jackson', 'E0100', 'NZ1', 'Manager' );
INSERT INTO employee(id, password, name, manager_id, outlet_id, role) VALUES ('E0102', 'm1234', 'Fisher Smith', 'E0100', 'NZ2', 'Manager' );
INSERT INTO employee(id, password, name, manager_id, outlet_id, role) VALUES ('E0103', 'm1234', 'Sarah David', 'E0100', 'NZ3', 'Manager' );
INSERT INTO employee(id, password, name, manager_id, outlet_id, role) VALUES ('E0104', 'm1234', 'Helen Zhou', 'E0100', 'NZ4', 'Manager' );
--admin and helpdesk;
INSERT INTO employee(id, password, name, manager_id, outlet_id, role) VALUES ('E1010', 'admin', 'Christine Bevan', 'E0100', '', 'Administrator' );
INSERT INTO employee(id, password, name, manager_id, outlet_id, role) VALUES ('E1011', 'h1234', 'Lisa Clarke', 'E0100', '', 'HelpDesk' );
INSERT INTO employee(id, password, name, manager_id, outlet_id, role) VALUES ('E1012', 'h1234', 'Emily Dan', 'E0100', '', 'HelpDesk' );
--workers;
INSERT INTO employee(id, password, name, manager_id, outlet_id, role) VALUES ('E2001', '123456', 'Frank Dawson', 'E0101', 'NZ1', 'Worker' );
INSERT INTO employee(id, password, name, manager_id, outlet_id, role) VALUES ('E2002', '123456', 'Mary Campbell', 'E0101', 'NZ1', 'Worker' );
INSERT INTO employee(id, password, name, manager_id, outlet_id, role) VALUES ('E2003', '123456', 'Helen Palmer', 'E0102', 'NZ2', 'Worker' );
INSERT INTO employee(id, password, name, manager_id, outlet_id, role) VALUES ('E2004', '123456', 'John Wilson', 'E0102', 'NZ2', 'Worker' );
INSERT INTO employee(id, password, name, manager_id, outlet_id, role) VALUES ('E2005', '123456', 'Geoff McKenzie', 'E0103', 'NZ3', 'Worker' );
INSERT INTO employee(id, password, name, manager_id, outlet_id, role) VALUES ('E2006', '123456', 'Fraser Osbourne', 'E0103', 'NZ3', 'Worker' );
INSERT INTO employee(id, password, name, manager_id, outlet_id, role) VALUES ('E2007', '123456', 'William Parker', 'E0104', 'NZ4', 'Worker' );
INSERT INTO employee(id, password, name, manager_id, outlet_id, role) VALUES ('E2008', '123456', 'Sheila Davies', 'E0104', 'NZ4', 'Worker' );
--customers;
INSERT INTO customer (id, name, address, phone) VALUES ('C0002', 'Samuel Tidders', '14 Hypertext Street, Wellington', '64-4-1111 111');
INSERT INTO customer (id, name, address, phone) VALUES ('C0003', 'Martha Matunda', '73 Radio Road, Christchurch', '64-3-2222 222');
INSERT INTO customer (id, name, address, phone) VALUES ('C0004', 'Harry T Square', '35 Draughty Way,Wellington', '64-9-3333 333');
INSERT INTO customer (id, name, address, phone) VALUES ('C0005', 'Jim Adder', '115 Calculator Road, Wellington', '64-4-4444 444');      
INSERT INTO customer (id, name, address, phone) VALUES ('C0006', 'Sally Hopkins', '22 Industrial Way, DownTown Auckland', '64-9-5555 555');
INSERT INTO customer (id, name, address, phone) VALUES ('C0007', 'Dennis Williams', '101 Small Road, Low Valley', '64-3-6666 777');
INSERT INTO customer (id, name, address, phone) VALUES ('C0008', 'Eric Mills ', '6 Numbers Street, Bean County, Invecargill', '64-3-7777 777');
INSERT INTO customer (id, name, address, phone) VALUES ('C0009', 'Annie Mathews', '271 Dove Street, Birdsville, Bay of Plenty', '64-7-8888 888');
INSERT INTO customer (id, name, address, phone) VALUES ('C0010', 'Sandy Jo', '271 Taram taa Street, Hawkes Bay', '64-6-9999 999');
INSERT INTO customer (id, name, address, phone) VALUES ('C0011', 'Chiller Raja', '271 Mantri Riviera, Auckland', '64-9-12345 678');
INSERT INTO customer (id, name, address, phone) VALUES ('C0012', 'Appu Kapur', '16 Tagtag Street, Wellington', '64-4-87654 321');
INSERT INTO customer (id, name, address, phone) VALUES ('C0013', 'Helen Clarke', '16 Sandringham Road, Auckland', '64-9-232323 333');
INSERT INTO customer (id, name, address, phone) VALUES ('C0014', 'Micheal Cullen', '23 Sissotto Ave, Hawkes Bay', '64-4-123123 444');
INSERT INTO customer (id, name, address, phone) VALUES ('C0015', 'Penny Mason', '249 Penny Ave, Christchurch', '64-3-454545 666');
INSERT INTO customer (id, name, address, phone) VALUES ('C0016', 'Sanjoy Varma',  '567 Rangitoto Street, Bay of Plenty', '64-7-567567 123');
INSERT INTO customer (id, name, address, phone) VALUES ('C0017', 'Xie Liu', '7 Sycamore Street, Invecargill', '64-5-898911 111');
INSERT INTO customer (id, name, address, phone) VALUES ('C0018', 'Lili Xu', '11 Whittiker Street, Wellington', '64-4-353535 444');
INSERT INTO customer (id, name, address, phone) VALUES ('C0019', 'Ana Shapirova', '13 Darrington Road, Auckland', '64-9-181818 888');
INSERT INTO customer (id, name, address, phone) VALUES ('C0020', 'Susan Campbell', '1489 Cadbury Street, Hamilton', '64-4-567911 222');
INSERT INTO customer (id, name, address, phone) VALUES ('C0021', 'John Campbell', '44 Singing Street, Whakatane', '64-9-123123 777');
INSERT INTO customer (id, name, address, phone) VALUES ('C0022', 'Alfred Chan', '1606 Flintstone Ave, Coromandel', '64-9-212121 212');

--cars;
INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('AXC12101', 'AXC 121', 'C0002', '2014-01-08 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('AMC22201', 'AMC 222', 'C0003', '2015-01-08 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('BCL47301', 'BCL 473', 'C0021', '2016-01-08 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('ADC67801', 'ADC 678', 'C0006', '2016-01-09 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('CMD45601', 'CMD 456', 'C0004', '2016-01-11 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('ADC47302', 'ADC 473', 'C0006', '2016-01-18 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('TTT47301', 'TTT 473', 'C0009', '2016-03-08 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('BVN47301', 'BVN 473', 'C0008', '2016-07-08 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('JZC52001', 'JZC 520', 'C0008', '2016-09-08 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('NIU01', 'NIU', 'C0005', '2017-01-10 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('LKF77701', 'LKF 777', 'C0005', '2017-01-08 11:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('PPP11101', 'PPP 111', 'C0010', '2017-03-12 11:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('CTY42001', 'CTY 420', 'C0002', '2017-04-17 15:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('BNM23401', 'BNM 234', 'C0022', '2017-10-11 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('AAA55501', 'AAA 555', 'C0011', '2017-12-10 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('EFG89801', 'EFG 898', 'C0011', '2017-12-12 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('ADD47301', 'ADD 473', 'C0011', '2017-12-13 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('BMW22201', 'BMW 222', 'C0012', '2017-01-02 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('ABF88901', 'ABF 889', 'C0013', '2018-01-03 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('BMV22201', 'BMV 222', 'C0014', '2018-02-02 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('ASD78901', 'ASD 789', 'C0021', '2018-02-18 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('PLK34501', 'PLK 345', 'C0015', '2018-03-16 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('PLM55501', 'PLM 555', 'C0016', '2018-05-02 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('XXX55501', 'XXX 555', 'C0016', '2018-06-21 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('ETFXBY01', 'ETF XBY', 'C0020', '2018-07-09 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('BBB88801', 'BBB 888', 'C0017', '2018-08-24 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('JJJ88801', 'JJJ 888', 'C0018', '2018-08-31 10:01:00');

INSERT INTO car (id, plate_id, customer_id, date_registered) 
	VALUES('XEF20301', 'XEF 203', 'C0019', '2018-10-31 10:01:00');

--jobs;
INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JP00001', 'Critical', 'AXC12101', 'NZ1', 'PanelBeating', 'Assigned', 'E1011', 'C0002', 'E2005', '2017-01-08 10:01:00', 'two big dents on the right side');
      
INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JP00002', 'Major', 'AXC12101', 'NZ2', 'PanelBeating', 'Assigned', 'E1012', 'C0002', 'E2005', '2015-05-23 17:35:01', 'bonnet has a big crack');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JP00003', 'Critical', 'AMC22201', 'NZ3', 'PanelBeating', 'Assigned', 'C0003', 'C0003', 'E2005', '2013-07-21 13:33:01', 'paint job on rear side');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JE00004', 'Critical', 'AMC22201', 'NZ4', 'Electical', 'Assigned', 'E1011', 'C0003', 'E2005', '2017-09-13 11:22:35', 'car does not start in cold weather even with new battery');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JM00005', 'Minor', 'BCL47301', 'NZ1', 'Mechanical', 'Assigned', 'E1011', 'C0021', 'E2007', '2014-11-16 18:22:35', 'wheel alignment');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JE00006', 'Critical', 'ADC67801', 'NZ2', 'Electical', 'Assigned', 'E1012', 'C0006', 'E2008', '2014-12-27 15:10:35', 'battery replacement');
     
INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JE00007', 'Major', 'CMD45601', 'NZ3', 'Electical', 'Assigned', 'E1012', 'C0004', 'E2007', '2015-05-27 15:49:35', 'problems with acceleration - check connection');
      
INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JE00008', 'Critical', 'CMD45601', 'NZ4', 'Electical', 'Assigned', 'E1011', 'C0004', 'E2003', '2015-11-19 13:10:23', 'spark plug needs to be replaced quickly');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JM00009', 'Minor', 'ADC47302', 'NZ1', 'Mechanical', 'Assigned', 'C0006', 'C0006', 'E2001', '2015-12-18 12:29:35', 'doors are loose');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JE00010', 'Major', 'TTT47301', 'NZ2', 'Electical', 'Assigned', 'E1012', 'C0009', 'E2002', '2016-01-12 11:56:35', 'engine stopped suddenly');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JE00011', 'Minor', 'BVN47301', 'NZ3', 'Electical', 'Assigned', 'E1012', 'C0008', 'E2005', '2016-01-22 14:02:18', 'check engine connections - some loose contact');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JP00012', 'Major', 'JZC52001', 'NZ4', 'PanelBeating', 'Assigned', 'E1011', 'C0008', 'E2001', '2016-03-09 11:43:18', 'door hinges are loose after collision');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JM00013', 'Critical', 'NIU01', 'NZ1', 'Mechanical', 'Assigned', 'C0005', 'C0005', 'E2008', '2016-06-08 16:02:18', 'brake pedal is very hard');
     
INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JM00014', 'Major', 'LKF77701', 'NZ2', 'Mechanical', 'Assigned', 'C0005', 'C0005', 'E2007', '2016-09-01 14:58:18', 'steering wheel moves to the right and does not stay at centre');
      
INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JP00015', 'Minor', 'PPP11101', 'NZ3', 'PanelBeating', 'Assigned', 'E1011', 'C0010', 'E2003', '2016-10-11 12:19:18', 'bumper broken');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JE00016', 'Minor', 'CTY42001', 'NZ4', 'Electical', 'Assigned', 'E1011', 'C0002', 'E2001', '2016-12-24 08:42:18', 'engine needs to be serviced properly');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JP00017', 'Critical', 'BNM23401', 'NZ1', 'PanelBeating', 'Assigned', 'E1012', 'C0022', 'E2004', '2016-12-29 10:21:18', 'windshield glass is cracked');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JP00018', 'Major', 'AAA55501', 'NZ2', 'PanelBeating', 'Assigned', 'E1012', 'C0011', 'E2001', '2017-01-04 08:14:36', 'right door handle is ineffective - window does not pull down');
	  
INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JM00019', 'Minor', 'EFG89801', 'NZ3', 'Mechanical', 'Assigned', 'E1012', 'C0011', 'E2003', '2017-01-27 11:20:18', 'brake, clutch and engine need to be realigned with new brushes');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JE00020', 'Major', 'ADD47301', 'NZ4', 'Electical', 'Assigned', 'C0011', 'C0011', 'E2008', '2017-01-27 13:52:18', 'battery drain - check all contacts');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JE00021', 'Major', 'BMW22201', 'NZ1', 'Electical', 'Assigned', 'C0012', 'C0012', 'E2004', '2017-01-31 16:20:37', 'tectronic gear box needs to be checked - maybe changed');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JM00022', 'Minor', 'BMW22201', 'NZ2', 'Mechanical', 'Assigned', 'E1011', 'C0012', 'E2007', '2017-02-17 13:26:18', 'all mirrors need to be replaced');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JM00023', 'Critical', 'ABF88901', 'NZ3', 'Mechanical', 'Assigned', 'E1011', 'C0013', 'E2008', '2017-02-22 10:31:47', 'send back to manufacturer - maybe the manufacture defect');
      
INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JE00024', 'Major', 'ABF88901', 'NZ4', 'Electical', 'Assigned', 'E1011', 'C0013', 'E2008', '2017-02-27 15:20:34', 'the car navigation attachment does not work');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JE00025', 'Minor', 'BMV22201', 'NZ1', 'Electical', 'Assigned', 'E1012', 'C0014', 'E2001', '2017-03-03 11:20:18', 'alarm goes off erratically for no reason');
      
INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JP00026', 'Major', 'BMV22201', 'NZ2', 'PanelBeating', 'Assigned', 'E1012', 'C0014', 'E2001', '2017-03-07 09:04:11', 're-paint');
     
INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JM00027', 'Major', 'ASD78901', 'NZ3', 'Mechanical', 'Assigned', 'E1012', 'C0021', 'E2001', '2017-03-15 12:12:40',  'worn suspension bearings');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JM00028', 'Minor', 'PLK34501', 'NZ4', 'Mechanical', 'Assigned', 'C0015', 'C0015', 'E2006', '2017-04-27 08:42:11', 'knocking sound from the front of the car');
      
INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JM00029', 'Critical', 'PLK34501', 'NZ1', 'Mechanical', 'Assigned', 'C0015', 'C0015', 'E2005', '2018-05-01 09:09:28', 'failed brake calliper');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JP00030', 'Major', 'PLM55501', 'NZ2', 'PanelBeating', 'Assigned', 'E1011', 'C0016', 'E2002', '2017-07-27 13:26:21', 'dents on bonnet and also paint job');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JM00031', 'Minor', 'PLM55501', 'NZ3', 'Mechanical', 'Assigned', 'E1011', 'C0016', 'E2004', '2017-08-07 14:29:18', 'check the wheel bearings');
      
INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JP00032', 'Critical', 'XXX55501', 'NZ4', 'PanelBeating', 'Assigned', 'E1012', 'C0016', 'E2004', '2017-09-14 10:35:08', 'window glass broken - all of them');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JE00033', 'Major', 'ETFXBY01', 'NZ1', 'Electical', 'Assigned', 'E1011', 'C0020', 'E2008', '2018-01-07 10:21:56', 'ignition problem');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JP00034', 'Minor', 'BBB88801', 'NZ2', 'PanelBeating', 'Assigned', 'E1011', 'C0017', 'E2007', '2015-04-21 15:20:14', 'left side pushed in');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JP00035', 'Minor', 'BBB88801', 'NZ2', 'PanelBeating', 'Assigned', 'C0017', 'C0017', 'E2002', '2018-06-12 14:19:31', 'roof needs a paint job');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JE00036', 'Critical', 'JJJ88801', 'NZ4', 'Electical', 'Assigned', 'C0018y', 'C0018', 'E2006', '2018-07-11 09:02:03',  'AC and dashboard meters are not working');

INSERT INTO job ( id, job_priority, car_id, outlet_id, job_type, job_status, created_by, customer_id, worker_id, date_reported, description)
VALUES('JM00037', 'Minor', 'XEF20301', 'NZ1', 'Mechanical', 'Assigned', 'E1012', 'C0019', 'E2002', '2018-09-25 19:12:11',  'clutch pedal gets stuck up');
