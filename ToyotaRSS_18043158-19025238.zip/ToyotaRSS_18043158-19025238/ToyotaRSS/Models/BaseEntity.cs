﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToyotaRSS.Models
{
    public class BaseEntity
    {
        public static string C_ID = "id";
        public static string C_DESC = "description";
        public static string DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss";

        private string _id;
        private string _description;

        public string id
        {
            get => _id;
            set { _id = value; }
        }
        public string description
        {
            get => _description ?? "";
            set { _description = value; }
        }

        public static string[] EnumNames(Type enumType)
        {
            return Enum.GetNames(enumType);
        }

        public static Object ToEnum(Type enumType, string value)
        {
            return Enum.Parse(enumType, value);
        }

        public static string JoinValues(string[] values)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < values.Length; i++)
                sb.Append("'").Append(values[i]).Append("',");
            sb.Length = sb.Length - 1;
            return sb.ToString();
        }
    }
}
