﻿DROP TABLE job_history; 
DROP TABLE job; 
DROP TABLE car; 
DROP TABLE customer; 
DROP TABLE employee; 
DROP TABLE outlet; 