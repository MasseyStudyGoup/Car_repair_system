﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ToyotaRSS.Models;
using ToyotaRSS.Security;

namespace ToyotaRSS.Controller
{
    public class ToyotaService
    {
        private static ToyotaService _instance = new ToyotaService();

        private static LogonManager m_logonManager = LogonManager.instance;
        private ToyotaService()
        {

        }

        public static ToyotaService Instance { get => _instance; }

        public IList<Outlet> GetOutlets()
        {
            return RSSDB.instance.QueryOutlets();
        }

        public IList<Car> GetMyCars()
        {
            if (m_logonManager.CurrentCustomer != null)
            {
                return RSSDB.instance.GetCarsByCustomer(m_logonManager.CurrentCustomer.id);
            }

            return RSSDB.instance.QueryCar(true);
        }

        public IList<Employee> GetMyWorkers()
        {
            if (m_logonManager.CurrentEmployee != null && m_logonManager.CurrentEmployee.role != EmployeeRole.Worker) 
            {
                if (m_logonManager.CurrentEmployee.role == EmployeeRole.Manager)
                {
                    return RSSDB.instance.GetEmployeesByManager(m_logonManager.CurrentEmployee.id);
                }
                else 
                {
                    return RSSDB.instance.AllEmployees();
                }
            }

            return new List<Employee>();
        }
        public IList<Job> GetMyJobs()
        {
            string querySql = "";
            if (m_logonManager.CurrentCustomer != null)
            {
                querySql = string.Format("SELECT * FROM {0} WHERE customer_id = '{1}' ORDER BY date_reported DESC", Job.TABLE_NAME, m_logonManager.CurrentCustomer.id);
            }
            else if (m_logonManager.CurrentEmployee != null)
            {
                Employee e = m_logonManager.CurrentEmployee;
                if (e.role == EmployeeRole.Worker)
                    querySql = string.Format("SELECT * FROM {0} WHERE worker_id = '{1}' ORDER BY date_reported DESC", Job.TABLE_NAME, e.id);
                else if (e.role == EmployeeRole.Manager && e.manager != null)
                    querySql = string.Format("SELECT * FROM {0} WHERE outlet_id = '{1}' ORDER BY date_reported DESC", Job.TABLE_NAME, e.outlet.id);
                else
                    querySql = string.Format("SELECT * FROM {0} ORDER BY date_reported DESC", Job.TABLE_NAME);
            }
            return RSSDB.instance.QueryJob(querySql);
        }

        public IList<Job> GetMyJobs(string jobStatus, string carId, string employeeId)
        {
            string condition = "";
            if (jobStatus != null && jobStatus.Length > 0)
            {
                if (jobStatus == "Resolved")
                    condition = condition + "job_status = 'Closed'";
                else if (jobStatus == "Unresolved")
                    condition = condition + "job_status <> 'Closed'";
            }

            if (carId != null && carId.Length > 0 )
            {
                string and = "";
                if (condition.Length > 0)
                    and = " and ";
                condition = condition + and + string.Format("car_id = '{0}'", carId);
            }
            Customer cust = m_logonManager.CurrentCustomer;
            Employee emp = m_logonManager.CurrentEmployee;

            if (cust == null && emp.role != EmployeeRole.Worker && employeeId != null && employeeId.Length > 0)
            {
                string and = "";
                if (condition.Length > 0)
                    and = " and ";
                condition = condition + and + string.Format("worker_id = '{0}'", employeeId);
            }
            string andClause = condition;
            if (condition.Length > 0)
                andClause = "and " + condition;

            string querySql = "";
            if (m_logonManager.CurrentCustomer != null)
            {
                querySql = string.Format("SELECT * FROM {0} WHERE customer_id = '{1}' {2}", Job.TABLE_NAME, cust.id, andClause);
            }
            else if (m_logonManager.CurrentEmployee != null)
            {
                Employee e = m_logonManager.CurrentEmployee;
                if (e.role == EmployeeRole.Worker)
                    querySql = string.Format("SELECT * FROM {0} WHERE worker_id = '{1}' {2} ORDER BY date_reported DESC", Job.TABLE_NAME, e.id, andClause);
                else if (e.role == EmployeeRole.Manager && e.manager != null)
                    querySql = string.Format("SELECT * FROM {0} WHERE outlet_id = '{1}' {2} ORDER BY date_reported DESC", Job.TABLE_NAME, e.outlet.id, andClause);
                else
                {
                    if (condition.Length > 0)
                        querySql = string.Format("SELECT * FROM {0} WHERE {1} ORDER BY date_reported DESC", Job.TABLE_NAME, condition);
                    else
                        querySql = string.Format("SELECT * FROM {0} ORDER BY date_reported DESC", Job.TABLE_NAME);
                }
            }
            return RSSDB.instance.QueryJob(querySql);
        }

        public IList<JobStatistic> SummarizeJobs()
        {
            if (LogonManager.instance.CurrentEmployee == null || LogonManager.instance.CurrentEmployee.role == EmployeeRole.Worker)
                return new List<JobStatistic>();


            return RSSDB.instance.StatisticJobs();
        }

        public Job UpdateJob(Job job)
        {
            return RSSDB.instance.UpdateJob(job);
        }
        public Job CreateJob(Job job)
        {
            return RSSDB.instance.CreateJob(job);
        }
    }
}
