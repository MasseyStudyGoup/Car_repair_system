﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ToyotaRSS.Models;

namespace ToyotaRSS.Security
{
    public class LogonManager
    {
        private static LogonManager _instance = new LogonManager();

        private Employee _currEmployee;
        private Customer _currCustomer;

        public static LogonManager instance { get => _instance; }

        public Employee CurrentEmployee
        {
            get => _currEmployee;
        }

        public Customer CurrentCustomer
        {
            get => _currCustomer;
        }

        public string CurrentUser
        {
            get
            {
                return (_currEmployee != null) ?  _currEmployee.name : (_currCustomer != null)?_currCustomer.name:"";
            }
        }

        public string CurrentUserId
        {
            get
            {
                return (_currEmployee != null) ? _currEmployee.id : (_currCustomer != null) ? _currCustomer.id : "";
            }
        }
        public bool IsSignedIn()
        {
            return (CurrentEmployee != null || CurrentCustomer != null);
        }

        public void Login(string user, string password)
        {
            Employee e = RSSDB.instance.GetEmployee(user);
            if (e == null)
            {
                Customer c = RSSDB.instance.GetCustomer(user);
                if (c == null)
                    throw new Exception("Your user name or password is not correct.");
                else
                    _currCustomer = c;
            }
            else
            {
                _currEmployee = e;
            }
        }
    }
}
