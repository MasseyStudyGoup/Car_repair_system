1. You MUST NOT delete ..\ToyotaRSS\bin\CreateTables.sql, it contains SQL statements for creating database and import testing data.
2. You may delete ToyotaRSS.db, the application will load testing data automatically. However, some relationships between the outlet, mananger and employee might not correct.  You may correct them on the UI by double click the job items and and update.
